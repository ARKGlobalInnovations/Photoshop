
These are the rules!

This font is free, but...

This orginal font design is mine. Don't put it on a CD or website or resell it in anyway without first contacting me (fontboy@subflux.com). If you want a friend to have it, send them a link to it (www.subflux.com/fonts.htm).

If you use this font, send me a link or JPG of the font in action, I love to see my babies at work. (fontboy@subflux.com)

Oh, and this font is offered as is, it may missing letters or stuff and if it blows up your machine don't blame me it isn't my fault.

Thanks for fonting,
MickeyRossi