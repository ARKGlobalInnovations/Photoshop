Unrender Font Foundry
All Files included are Copyright 1999 Zane Townsend.

Web Site:  http://www.Unrender.com/
Email:    ztownsend@hotmail.com
______________________________________________________________________________

Revision notes: 2nd release. Major overhaul, added lower-case orbits.


Special character notes:  To add more orbits around your capital letters use the open bracket, close bracket and backslash keys before the letter. Example keystrokes "[]M" (no quotes) will give you 3 orbits around M. To get orbits around the lowercase letters use the {}| before the letter like this "{}|a" (no quotes) will triple orbit a lowercase letter.

Other Notes: I made this font for my girlfriend (Now she is my wife) Lisa, she studies Japanese language so I titled it with the Japanese-ifyed pronunciation of her name.
______________________________________________________________________________
